'use strict';

function noop () {}

module.exports = noop;
